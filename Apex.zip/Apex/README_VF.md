Using Visualforce and Apex to Build Dynamic Screens with Flow REST API

Overview:
This code relies completely on Visual Workflow for all fields, form validation, decision-making, etc. To display this information in a more user-friendly way, I used JavaScript in combination with Visualforce and Apex.

The basic structure: each screen is represented by a screen class. These screens are tracked in lists, with each list representing a page from the user's perspective. The Apex controller tells the Visualforce markup which lists of screens to display, and the Visualforce and JavaScript work together to properly display them.

1. New Pages
Multiple screens can now be displayed on one page. By monitoring a flag at the beginning of the screen names, the app controls when a new page starts without having to hard-code each flow. In this code, that flag is "New", i.e. "New_MyScreen".

When a new screen is created with that flag in its name, the Apex controller moves the current list of screens to the list representing old pages, leaving the new screen as the only one in the list representing the current page. This way, the Visualforce displays pages that can contain many flow screens at once.

2. Back
This custom pagination introduces a new problem: what does it mean for a user to click "Back"? The API offers a back option, but this back only moves the API back one screen.

When users click Back, they expect to return to the previous page. This means removing all screens on the current page, and displaying all screens which were visible on the last page. Because of this, the app ignores the API's back option and handles this UX independently of any REST calls. When a user clicks Back, the Apex controller replaces the current list of screens with the most recent previous list. Because of this behavior, it's important to store old screens instead of removing them completely. Luckily for us, each screen in an interview has its own state ID, and these IDs remain meaningful even after the user has initially moved past that screen. So if another PATCH is called using that state ID, the call is still meaningful and will proceed as if the interview had taken that route initially.

As long as each screen keeps track of its own state, you don't have to call "Back” on the API. You can remove the now-irrelevant screens and proceed from the final screen on the previous page as if nothing had happened.

3. Multiple Screens per "Page"
When users see multiple screens, they might attempt to alter information that’s already been passed to the API. To handle this, each div is covered by an event handler. When the user clicks on a div that's still visible but isn't the most recent div, the JavaScript removes all divs after the clicked div from the DOM (but these screens still exist in the Apex controller). When a new API call is made, the Apex controller first looks at which screen the call came from, and if it didn't come from the Apex controller's currentScreen, the controller also removes any screens after the clicked screen and updates currentScreen before making the appropriate API call.

You can position screens either on the left half of the screen, right half, or have the screen take up the entire width of the screen. To control this, add either "Left" or "Right" to the ending of the screen name. You can add "Full" to the end as well, but if you don't specify left or right, then it will automatically assume full. So for example, you can have "MyScreen_Right" for a screen on the right column of the page.

4. Triggers
Instead of forcing the user to select a radio button and then click Next, make the radio buttons themselves triggers that continue to the next page. You can do this by adding a simple flag to the name of the radio button, i.e. Trigger_MyRadioButton. You probably only want to do this when the radio buttons are at the end of a screen. In this code, after each screen is generated, the JavaScript searches for radio buttons with “Trigger_” at the beginning of the name, and adds an eventListener to any it finds.

NOTE: Along with minimal custom CSS, this app uses Bootstrap--http://getbootstrap.com/css/
