<!DOCTYPE html>
<?php
// ini_set('display_errors', 'On');?>
<html>
<head>
<title><?php echo $_POST['flowName']; ?></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="flows.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="flows.js" type="text/javascript"></script>
<script src="picklist.js" type="text/javascript"></script>
</head>
<body>
<div id="content" style="width:90%">
<div id="container" class="container" style="width:100%">
<script type="text/javascript">
	setUp("<?php echo $_POST['flowName'] ?>", "<?php echo $_POST['server'] ?>", "<?php echo $_POST['access'] ?>");
</script>
</div>
</div>
</div>
</body>
</html>
