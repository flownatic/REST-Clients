/* These variables are used for communication with Salesforce */
var flowName; // Name of flow
var server; // Name of Salesforce server
var guid; // Current interview GUID
var access; // Access code for authentication

/* These variables are used to maintain UI */
var divs; // List of divs containing individual screens, maintained so that display can be manipulated independently of API calls
var paused; // Boolean indicating whether flow interview has been paused
var twoColumn; // Boolean indicating whether new screens should be seperated into left/right columns
var pageCount; // Count used to whether a back button is needed

/* This function intializes the necessary variables, and adds the first screen and header to the page */
function setUp(f, s, a){
	flowName = f;
	server = s;
	access = a;
	divs = [];
	paused = false;
	twoColumn = false;
	pageCount = 0;
	
	var xml = new XMLHttpRequest();
	var newDiv = document.createElement('div'); // Initialize new div to contain first screen
	xml.onreadystatechange = function(){ // Define function to be executed once initial call is made to screen.php/REST API
		if(xml.readyState == 4 && xml.status == 200){
			newDiv.innerHTML = xml.responseText; // Insert response from screen.php into new 
			var screenName = newDiv.children[2].id;
			document.getElementById('container').appendChild(newDiv); // Put new div into page
			newDiv.id = "0"; //Future div ids come from the length of the "divs" array. This can be hardcoded because it is always the first
			divs.push(newDiv); // Store div in array

			/* Because the API calls are made in screen.php, this is the easiest way to store the guid for future use */
			guid = document.getElementById('guid').value;

			/* The header gets initialized with the first screen, but it needs to be removed from this div so it can persist independently of the screens */
			var header = document.getElementById('page-header'); 
			header.parentElement.removeChild(header);
			document.getElementById('container').insertBefore(header, document.getElementById('container').firstChild);

			var position = screenName.split('_')[screenName.split('_').length - 1].toLowerCase();
			if(position == 'right' || position == 'left') {
				newDiv.className = position == 'right' ? 'right' : 'left';
			}
			else
				newDiv.className = 'full';

			/* In fully generic version, triggers should be called here to account for possible trigger buttons on first screen */
			try{
				triggers(screenName);
			}
			catch(err){}
		}
	}

	xml.open("POST","screen.php",true); // Post to screen.php which will make the API call
        xml.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xml.send('&access=' + access + '&server=' + server + '&flow=' + flowName + '&inputs=[]&action=POST'); // Ppass information for API call as POST variables
}

/* This function handles all future REST calls */
function PATCH(div, state){
	
	/* This block builds the inputs that'll be passed to the REST call */
	var inputs = '{"screenInputs":{';
	form = document.forms[document.forms.length - 1];
	for(var i = 0; i < form.length; i++){
		if(form.elements[i].type != 'hidden' && form.elements[i].type != 'submit' && form.elements[i].type != 'button'){ // Record all user inputs. Ignore buttons and the interview state--which is recorded in a hidden input
			if(form.elements[i].type == 'radio' || form.elements[i].type == 'select-one'){ // Handle radio buttons and drop-down list
				if(form.elements[i].checked == true || form.elements[i].type == 'select-one'){
					inputs = inputs + '"' + form.elements[i].name + '.' + form.elements[i].value + '.selected":"true",';
				}
			} else if(form.elements[i].id.indexOf('_selected') > -1) {
				var name = form.elements[i].id.replace('picklist_','');
				name = name.replace('_selected','');
				var selectedOptions = form.elements[i].options;
				for(var x = 0; x < selectedOptions.length; x++)
					inputs = inputs + '"' + name + '.' + selectedOptions[x].id + '.selected":"true",';
			} else if(form.elements[i].type == 'checkbox') {
				if(form.elements[i].checked) {
					if(form.elements[i].placeholder != '')
						inputs = inputs + '"' + form.elements[i].placeholder +'.' + form.elements[i].name + '.selected":"true",';
					else
						inputs = inputs + '"' + form.elements[i].name + '":true,';
				}
			} else if (form.elements[i].value != '' && form.elements[i].type != 'select-multiple') { // Handle all other non-null inputs
				inputs = inputs + '"' + form.elements[i].name + '":"' + form.elements[i].value + '",';
			}
		}
	}
	inputs = inputs.slice(0, -1);
	if(inputs == '{"screenInputs":')
		inputs = '{"action":"' + div.id.toUpperCase() + '","state":"' + state + '"}';
	else
		inputs = inputs + '},"action":"' + div.id.toUpperCase() + '","state":"' + state + '"}';


	var newDiv = document.createElement('div'); // Initialize div to contain new screen
	var xml = new XMLHttpRequest();
	xml.onreadystatechange = function(){ // Define function to be executed once call is made to screen.php/REST API
		if(xml.readyState == 4 && xml.status == 200) {
			newDiv.innerHTML = xml.responseText; // Insert response from screen.php into new div
			var screenName = newDiv.children[0].id;

			/* If this screen has the same name as the screen just prior to it, it means the same screen was returned with error messages. 
			This block removes prior version of screen and replaces it with the error version. */
			if(divs[divs.length - 1].children[0].id == screenName){ //
				divs[divs.length - 1].removeChild(divs[divs.length - 1].children[0]); // Replace content of div with new screen, so div array and outer div(with possible left/right distinction) doesn't change
				divs[divs.length - 1].innerHTML = xml.responseText;
				if(document.getElementById('RESUME') || document.getElementById('Resume')){ // If there is a Resume button, the flow has been paused, which needs to be handled in the display seperately from the API call
					pause();
				} else if(paused){ //If no Resume button but global variable "paused" is set to true, the flow interview was just resumed and the display needs to be adjusted
					resume();
				}
			/* Else, you're adding a completely new screen */
			} else {
				/* If the previous screen had errors, even once they get fixed and the API returns the next screen, the previous screen will still be displaying the fields as errors. This prevents that issue. */
				var formGroups = divs[divs.length - 1].getElementsByTagName('form')[0].getElementsByTagName('div');
				for(var i = 0; i < formGroups.length; i++){
					var classes = formGroups[i].className.split(" ");
					if(classes.indexOf("has-error") > -1){
						delete classes[classes.indexOf("has-error")];
						formGroups[i].className = classes.join(" ");
						var help = formGroups[i].getElementsByTagName("p");
						for(var j = 0; j < help.length; help++){
							help[j].parentNode.removeChild(help[j]);
						}
					}
				}
				/* If the beginning of a screen ame has the 'New' flag, the screen starts a new page for the user */
				if(screenName.split("_")[0] == 'New'){
					for(var i = 0; i < divs.length; i++){ // Hide all previous screens
						divs[i].style.display = "none";
					}
					pageCount++; 
					twoColumn = false;
				}
				/* Before appending the new screen, hides buttons for all other screens on the page.
					Once the new screen is appended, only it's buttons will be shown to the user.*/
				var inputs = document.getElementsByTagName('input');
				for(var i = 0; i < inputs.length; i++){
					if(inputs[i].type === 'submit'){
						inputs[i].style.display = 'none';
					}
				}

				if(screenName == '') {
					newDiv.className = divs[divs.length-1].className;
				}

				document.getElementById('container').appendChild(newDiv);

				/* The div has been appended to the screen, but it hasn't been added to the divs array. 
					"prevDiv" represents the id of the div that contains the previous screen. */
				var prevDiv = divs.length - 1;
				divs[divs.length - 1].addEventListener('click', function(){ // Attach an event listener to the previous div, for when the user attempts to edit a screeen other than the current one
					divClicked(prevDiv);
				}, true);
				newDiv.id = divs.length; // The div containing a screen is labeled with simply a number, indicating which number screen it holds
				divs.push(newDiv); // Finally, add new div to divs array
			}

			var position = screenName.split('_')[screenName.split('_').length - 1].toLowerCase();
			if(position == 'right' || position == 'left') {
				newDiv.className = position == 'right' ? 'right' : 'left';
			}
			else if(screenName != '')
				newDiv.className = 'full';

			/* Handle the need for a Back button */
			if(pageCount > 0 && !(document.getElementById('RESUME')) && !(document.getElementById('START OVER'))) {
				var backButtonDiv = document.createElement('div');
				try {
				document.getElementById('back').parentNode.removeChild(document.getElementById('back'));
				} catch(err) {}
				backButtonDiv.id = "backButton";
				backButtonDiv.innerHTML = '<input type="submit" id="back" class="btn btn-default" value="BACK">';
				var buttons = document.getElementsByClassName('btn-group');
				console.log("buttons" + buttons + " " + buttons[0]);
				buttons[buttons.length - 1].appendChild(backButtonDiv.children[0]);
				document.getElementById('back').onclick = function() {
					event.preventDefault();
					back();
				};
				console.log(buttons[buttons.length - 1].children[buttons[buttons.length - 1].children.length - 1].id);
				console.log("got in here");
			}

			/* Future_promos and triggers run on every screen, but they won't always have something to do.
				When they throw an error, they ran on screens they weren't meant for, so those errors can be ignored. */
			try{
				future_promos();
			}
			catch(err){}
			try{
				triggers(screenName);
			}
			catch(err){}
		}
	}

	if(document.getElementById('pageCount') != null) {
		document.getElementById('pageCount').value = pageCount;
	}

	xml.open("POST","screen.php",true);
	xml.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	xml.send("state=" + state + "&guid=" + guid + "&access=" + access + "&server=" + server + "&flow=" + flowName + "&inputs=" + inputs + "&action=PATCH");
}	

/* This function executes when someone clicks Back. */
function back(){
	pageCount--;
	twoColumn = false;

	divs.reverse(); // Step backwards through div array 
	while(divs[0].children[0].id.split("_")[0] != 'New'){ // Remove divs until you find the first div on this page
		divs[0].parentNode.removeChild(divs[0]); // Remove from DOM
		divs.shift(); // Remove from div list
	}
	divs[0].parentNode.removeChild(divs[0]); // Remove first div on page from DOM...
	divs.shift(); // ...and div list
	for(var i = 0; i < divs.length; i++){ // Until you find the first div of the previous page, make all divs visible
		divs[i].style.display = "inline";
		if(divs[i].children[0].id.split('_')[0] === 'New'){
			i = divs.length;
		}
	}
	divs.reverse(); // Return div list to proper order

	/* Normally all buttons on the last div of the page should be restored, but if the screen has a trigger, the Next button should remain hidden */
	var inputs = divs[divs.length - 1].getElementsByTagName('input');
	var foundTrigger = false;
	for(var i = 0; i < inputs.length; i++){
		if(inputs[i].name.split("_")[0] == "Trigger"){
			foundTrigger = true;	
		}
		if(inputs[i].type == 'submit' && !(foundTrigger && inputs[i].id.toLowerCase() == 'next')){ // By the time you get to the buttons, you would have already found the trigger
			inputs[i].style.display = "inline";
		}
	}
	/* Handle the possible need for another Back button */
	if(pageCount > 0){
		var backButtonDiv = document.createElement('div');
		backButtonDiv.id = "backButton";
		backButtonDiv.innerHTML = '<input type="submit" id="back" class="btn btn-default" value="BACK">';
		var buttons = document.getElementsByClassName('btn-group');
		console.log("buttons" + buttons + " " + buttons[0]);
		buttons[buttons.length - 1].appendChild(backButtonDiv.children[0]);
		document.getElementById('back').onclick = function() {
			event.preventDefault();
			back();
		};
		console.log(buttons[buttons.length - 1].children[buttons[buttons.length - 1].children.length - 1].id);
		console.log("got in here");
	}
}

/* When a flow has been paused, all screens should go away except for the screen with the Resume button */
function pause(){
	console.log(divs);
	for(var i = 0; i < divs.length - 1; i++){
		divs[i].style.display = "none";
	}
	paused = true;
}

/* When a flow interview gets resumed, the screens on the current page should come reappear */
function resume(){
	paused = false;
	divs.reverse(); //Step through flows backwards
	for(var i = 0; i < divs.length; i++){
		if(divs[i].children[0].id.split("_")[0] == 'New'){ // Look for the first screen on this page
			divs[i].style.display = "inline";
			divs.reverse();
			return;
		}
		divs[i].style.display = "inline";
	}
	divs.reverse();	
}

/* This function is called when a div is clicked after it has been moved past (i.e. it's no longer the current screen). */
function divClicked(screenName){
	if((document.getElementById('START OVER'))){
		return;
	}
	if(divs[divs.length - 1].id == screenName){ // If the div is now the most current div again (i.e. after Back has been clicked), don't do anything
		return;
	}
	divs.reverse(); // Step backwards through div array
	var i = 0;
	while(divs[0].id != screenName){ // Remove all screens (divs) that came after the screen that got clicked on
		var temp = divs.shift();// Remove from div list
		temp.parentNode.removeChild(temp);// Remove from DOM
	}
	divs.reverse();// Return div list to proper order
	var children = document.getElementById(screenName).children[0].getElementsByTagName('input');// Make this screen's buttons visible again
	if(children.length == 0)
		children = document.getElementById(screenName).children[1].getElementsByTagName('input');
	for(var i = 0; i < children.length; i++){
		if(children[i].type.toLowerCase() == 'submit'){
			children[i].style.display = "inline";
		}
	}
	if(pageCount > 0){
                var backButtonDiv = document.createElement('div');
                backButtonDiv.id = "backButton";
                backButtonDiv.innerHTML = '<input type="submit" id="back" class="btn btn-default" value="BACK">';
                var buttons = document.getElementsByClassName('btn-group');
                console.log("buttons" + buttons + " " + buttons[0]);
                buttons[buttons.length - 1].appendChild(backButtonDiv.children[0]);
                document.getElementById('back').onclick = function() {
                        event.preventDefault();
                        back();
                };
                console.log(buttons[buttons.length - 1].children[buttons[buttons.length - 1].children.length - 1].id);
                console.log("got in here");
        }
}

/* This function attaches appropriate event listeners to any radio buttons that are meant to act as triggers for the next page (so the user doesn't have to click Next) */
function triggers(screenName){
	var found = false;
	var fields = document.getElementById(screenName).getElementsByTagName("form")[0].getElementsByTagName("div"); // Grab all divs on current screen
	for(var i = 0; i < fields.length; i++){
		var inputs = fields[i].getElementsByTagName("input");
		if(fields[i].className == 'form-group'){ // Prevents finding the same input twice, if it is technically within two (nested) divs
			for(var j = 0; j < inputs.length; j++){
				var name = inputs[j].id;
				name = name.split("_");
				if(name[0] === 'Trigger'){ // Check whether the input is a trigger
					/* Browsers handle nested event handlers strangely. For details on the "true" at the end of this method call, refer to the READ ME */
					inputs[j].addEventListener('click', function() { nextScreen(screenName); }, true); // Attach appropriate function
					this.found = true; // Indicate at least one trigger was found
				}
			}
		}
	}
	if(this.found){ // If a trigger was found, remove the Next button from the screen
		fields = document.getElementById(screenName).getElementsByTagName("form")[0].getElementsByTagName("input");
		for(var i = 0; i < fields.length; i++){
			if(fields[i].value == 'Next' || fields[i].value == 'NEXT' && fields[i].type == 'submit'){
				fields[i].style.display = 'none';
			}
		}
	}
	this.found = false;
}

/* This function gets attached to any radio buttons marked "Trigger" */
function nextScreen(screenName){
	var inputs = document.getElementById(screenName).getElementsByTagName('input');
	for(var i = 0; i < inputs.length; i++){// Loop through inputs looking for the Next button
		if(inputs[i].id.toLowerCase() == 'next'){
			inputs[i].click();// Once found, click the button
			return;
		}
	}
}

function errorPosition() {
	var errorDiv = document.getElementById('errorMessage');

}

/******************************************************/
/* These next four functions are hard-coded to handle */	
/* the future promotion radio buttons, and how they   */
/* affect the text boxes beneath them. For details,   */
/* please refer to the READ ME.                       */
/******************************************************/
function future_promos(){
	document.getElementById('Yes_Email').onclick = function() { byEmail(); };
	document.getElementById('Yes_Text').onclick = function() { byText(); };
	document.getElementById('No_thanks').onclick = function() { hideFields(); };
	hideFields();
}

function hideFields(){
	// If a radio button has already been clicked, these ifs ensure that the corresponding text box doesn't get hidden when future_promos is called in the future
	if(!document.getElementById('Yes_Text').checked){
		document.getElementById('Promo_Phone').style.display = "none";
	}
	if(!document.getElementById('Email').checked){
		document.getElementById('Email').style.display = "none";
	}
}

function byEmail(){
	document.getElementById('Promo_Phone').style.display = "none";
	document.getElementById('Email').style.display = "inline";
}

function byText(){
	document.getElementById('Promo_Phone').style.display = "inline";
	document.getElementById('Email').style.display = "none";
}

