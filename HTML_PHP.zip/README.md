Building Dynamic Screens with Flow REST API
By: Jesenia Garcia-Rovetta

Overview:
This code relies completely on Visual Workflow for all fields, form validation,
decision making, etc. To display this information in a more 
user-friendly way, I used a combination of PHP and JavaScript along with basic HTML
and CSS.

The basic structure: every screen is encapsulated by a single div. These divs can
be manipulated with CSS to create the desired user experience. AJAX and cURL calls are
used to communicate with the API, so that the page never has to be refreshed. This 
means that even though the user clicks through various pages, this effect is created by
keeping track of the divs and making them appear, disappear,
and reappear.

1. Setup
To initially set up using this client, you need to add a connected app to your org. From there, you can get a consumer key and consumer secret which can then be placed in listFlows.php as values for client_id and client_secret. This sets up the app to have access to your org when making curl calls. When adding the server name during login, make sure to not include the "http://" in the beginning and the "/" at then very end. 

2. "New" Pages
Multiple screens can now be displayed on one page. By monitoring a flag
at the beginning of the screen names, the app controls when a new page starts without having to hardcode for each flow. In this code, that flag is "New", i.e. “New_MyScreen”.

When the app encounters this flag, the JavaScript loops through all the existing screen divs
and sets their display style to none before appending the new screen to the page. In 
this way, the app gives the user the impression of a new page.

3. Back
This custom pagination introduces a new problem: what does it mean for a user to click 
"Back"? The API offers a back option, but this back only moves the API back one screen.

When users click "Back" they expect to return to the previous page. This means removing all screens on the current page, and displaying all screens which had been visible to them on the last page. Because of this, the app ignores the API's back option and handles this UX independently of any REST calls. When a user clicks "Back", JavaScript removes all screens that exist on the current page and resets the display style for all the divs that were on the previous page. This behavior is why it’s important to hide old divs instead of removing them from the page. Luckily for us, each screen in an interview has its own state ID, and these IDs remain meaningful even after the user has initially moved past that screen. So if another PATCH is called using that state ID, the call is still meaningful and will proceed as if the interview had taken that route initially.

As long as each screen keeps track of its own state, you don’t have to call "Back" on the API. You can remove the now-irrelevant screens and proceed from the final screen on the previous page as if nothing had happened.

4. Multiple Screens per "Page"
When users see multiple screens, they might attempt to alter information they entered before--which has already been passed to the API. To handle this, each div is covered
by an eventHandler. When the user clicks on a div that’s still visible but isn’t the 
most recent div, the app removes all divs after the clicked div. In order to move forward again, brand new API calls must be made to populate new screens, so that everything remains valid.

You can position screens either on the left half of the screen, right half, or have the screen take up the entire width of the screen. To control this, add either "Left" or "Right" to the ending of the screen name. You can add "Full" to the end as well, but if you don't specify left or right, then it will automatically assume full. So for example, you can have "MyScreen_Right" for a screen on the right column of the page. 

5. Triggers
Instead of forcing the user to select a radio button and then click Next, make the radio buttons themselves triggers that continue to the next page. You can do this by adding a simple flag to the name of the radio button, i.e. Trigger_MyRadioButton. You probably only want to do this when the radio buttons are the last field on a screen. In this code, whenever a new screen is attached to the page, JavaScript searches for radio buttons with the appropriate name, and adds an eventListener to any it finds.
	5a. Important: Be aware of the way browsers handle nested eventListeners. 
If events  don't seem to be firing correctly, this is a good place to investigate 
first. Because of the way nested eventListeners are handled, this code 
sometimes assigns a value to onclick, and sometimes uses the 
addEventListener function.

6. Radio Buttons that Hide/Show Other Fields
The event listeners surrounding the "future_promos" radio buttons are the only things hard-coded in this code. These event listeners are used to show/hide input fields based on which of the “future_promos” radio buttons is selected. This is simply a further example of the cool things that are now possible. It’s hard-coded because there’s no way to indicate the desired functionality with a simple flag.

NOTE: Along with minimal custom CSS, this app uses Bootstrap--http://getbootstrap.com/css/
