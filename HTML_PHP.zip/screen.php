<?php
// These variables are passed in as a url, which replaces '+' with spaces. These next few lines remedy this change
// ini_set('display_errors', 'On');
$curl = curl_init();
$guid = explode(' ', $_POST['guid']);
$guid = implode('+', $guid);
$state = explode(' ', $_POST['state']);
$state = implode('+', $state);
$access = explode(' ', $_POST['access']);
$access = implode('+', $access);
$header = 'Authorization: Bearer ' . $_POST['access'];
$inputs = explode(' ', $_POST['inputs']);
$inputs = implode('+', $inputs);

// Determine which url to used
if($_POST['action'] === 'POST'){
	$url = 'http://' . $_POST['server'] . '/services/data/v36.0/process/interviews/' . $_POST['flow'];
} else {
	$url = 'http://' . $_POST['server'] . '/services/data/v36.0/process/interviews/' . $_POST['flow'] . '/' . $guid;
}

// Make API call
curl_setopt_array($curl, array(
	CURLOPT_RETURNTRANSFER => 1,
	CURLOPT_URL => $url,
	CURLOPT_POST => 1,
	CURLOPT_POSTFIELDS => $inputs,
	CURLOPT_CUSTOMREQUEST => $_POST['action'],
	CURLOPT_HTTPHEADER => array($header, 'Accept: application/json', 'Content-Type: application/json; charset=UTF-8')
));
// Store json returned by API
$resp = curl_exec($curl);
// Convert json to map
$json = json_decode($resp);
curl_close($curl);
// Store all the fields of the screen
$fields = $json[0]->{'screenFields'};
$error = $json[0]->{'message'};

// If this call was a POST, adds the first screen. This is where the header gets added, and how the guid gets passed to the Javascript
if($_POST['action'] === 'POST'){?>
<input type="hidden" id="guid" value="<?php echo $json[0]->{'guid'} ?>" />
<div id="page-header" style="overflow:hidden;">
		<img src="newlogo-company.png" height="50px" width="78px" style="float:left; margin-right:20px;">
        <h1 style="float:left;"><?php echo $json[0]->{'flowLabel'} ?></h1>
</div>
<?php
}?>

<div id="<?php echo $json[0]->{'screenName'} ?>">

<form>
<input type="hidden" name="interview" value="<?php echo $json[0]->{'state'} ?>"/>
<?php if(isset($error)) { ?>	
	<div class="alert alert-danger" role="alert" aria-hidden="true" id="errorMessage">
		<script type="text/javascript"></script>
		<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
		<?php echo $error ?>
	</div>
<?php } ?>
<?php
if($fields){ // If false, flow interview been paused or finished
foreach($fields as $field){ // Loop through all the fields to display them properly
?><div class="form-group<?php
	if($field->{'errorMessages'}){ // If there are error messages, add an extra class for the css
		echo ' has-error';
	}?>" id="<?php echo $field->{'name'} ?>"><?php
	if($field->{'fieldType'} === 'DISPLAY_TEXT'){
		?><p><?php echo $field->{'label'} ?></p><?php
	} else {0
		?> <label class="full"> <?php echo $field->{'label'} ?> </label>
		<?php
		if($field->{'fieldType'} === 'INPUT' || $field->{'fieldType'} === 'PASSWORD'){?>
			<input class="form-control" type=
			"<?php
			if($field->{'dataType'} === 'BOOLEAN'){
				echo 'checkbox';
			} else if($field->{'fieldType'} === 'PASSWORD'){
				echo 'password';
			} else if($field->{'dataType'} === 'DATEONLY'){
				echo 'date';
			} else {
				echo 'text';
			}
			?>" name="<?php echo $field->{'name'} ?>" <?php
                        if($field->{'fieldType'} === 'BOOLEAN' && $field->{'value'} == 'true'){
                                echo 'checked';
                        } else if($field->{'value'}){
                                echo 'value="' . $field->{'value'} . '"';
                        }?>>
		<?php	
		} else if($field->{'fieldType'} === 'LARGE_TEXT_INPUT'){?>
			<textarea class="form-control" name="<?php echo $field->{'name'}?>" rows="4" cols="50"><?php
                        if($field->{'value'}){
                                echo $field->{'value'};
                        }
                        ?></textarea><?php
		} else if($field->{'fieldType'} === 'RADIO_BUTTONS'){
			foreach($field->{'choices'} as $choice){?>
			 <div class="radio"><label class="control-label">
				<input type="radio" id="<?php echo $choice->{'name'} ?>" name="<?php echo $field->{'name'} ?>" value="<?php echo $choice->{'name'} ?>" <?php
                                if($choice->{'isSelected'} == 'true'){
                                        echo 'checked';
                                }?>><?php
				echo $choice->{'label'};
				?></label></div><?php
			}
		} else if($field->{'fieldType'} === 'DROPDOWN'){
			?><select name="<?php echo $field->{'name'}?>" class="dropdown"><?php
			foreach($field->{'choices'} as $choice){?>
				<option value="<?php echo $choice->{'name'} ?>" <?php
                                if($choice->{'isSelected'}){
                                        echo 'selected';
                                }?>><?php
				echo $choice->{'label'};
				?><br/><?php
			} 
			?></select><?php
		} else if($field->{'fieldType'} === 'PICKLIST'){
			?><select multiple id="picklist_<?php echo $field->{'name'}?>" name="<?php echo $field->{'name'}?>[]" style="display:none;">
				<?php foreach($field->{'choices'} as $choice){?>
					<option value ="<?php echo $choice->{'name'} ?>"><?php
					echo $choice->{'label'};
					?><br/><?php
				}?>
			</select>
			<table class="MSPTable">
				<tbody>
					<tr class="MSPRow">
						<td>
							<select multiple class="form-control" id="picklist_<?php echo $field->{'name'}?>_unselected">
								<?php 
									$i = 0;
									foreach($field->{'choices'} as $choice){?>
										<option value ="<?php echo $i ?>" id ="<?php echo $choice->{'name'} ?>"><?php
										echo $choice->{'label'};
										?><br/><?php
										$i = $i + 1;
									}
							?></select>
						</td>
						<td class="MSPButtons">
							<input type="button" value ="Select >>" style="width:100px; margin-left:5px; margin-right:5 px; margin-bottom: 5px;" onClick="handleMSP(document.getElementById('picklist_<?php echo $field->{'name'}?>_unselected'),document.getElementById('picklist_<?php echo $field->{'name'}?>_selected'))">
							<br>
							<input type="button" value ="<< Remove" style="width:100px; margin-left:5px; margin-right:5 px;" onClick="handleMSP(document.getElementById('picklist_<?php echo $field->{'name'}?>_selected'),document.getElementById('picklist_<?php echo $field->{'name'}?>_unselected'))">
						</td>
						<td>
							<select multiple class="form-control" id="picklist_<?php echo $field->{'name'}?>_selected">
							</select>
						</td>
					</tr>
				</tbody>
			</table><?php
		} else if($field->{'fieldType'} === 'CHECKBOXES'){
			?><br><?php 
			foreach($field->{'choices'} as $choice){
				?><input type="checkbox" name="<?php echo $choice->{'name'} ?>" placeholder="<?php echo $field->{'name'}?>" value="<?php echo $choice->{'label'}?>" <?php
                                if($choice->{'isSelected'}){
                                        echo 'checked';
                                }?>><?php
				echo $choice->{'label'};
				?><br/>
			<?php
			}
		} else {?>
			<p><?php echo $field->{"fieldType"} ?></p>
		<?php
		}	
	}
	if($field->{'errorMessages'}){ //Print out error messages
		?><p class="help-block"><?php
		foreach($field->{'errorMessages'} as $message){
			echo $message;
		}
		?></p><?php
	} else if($field->{'isRequired'} === 'true'){ //Or indicate required
		?><p class="help-block">Required</p><?php
	}
?></div><?php
}
}

?><div class="btn-group"><?php
if(empty($json[0]->{'availableActions'}) && $json[0]->{'interviewStatus'} === 'FINISHED') { ?>
	<input type="hidden" id="pageCount" name="pageCount">
	<input type="submit" class="btn btn-default" name="action" value="START OVER" id="START OVER" onclick="window.history.back(<?php echo $pageCount?>);"/>
<?php }
foreach($json[0]->{"availableActions"} as $action){//Create a button for every action EXCEPT BACK
	if($action != 'BACK'){?>
	<input type="submit" class="btn btn-default" name="action" value="<?php echo $action ?>" id="<?php echo $action ?>" onclick="event.preventDefault(); PATCH(this, '<?php echo $json[0]->{'state'} ?>');"/>
<?php
}
}
?>
</div>
</form>
</div>
