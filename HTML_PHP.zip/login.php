<!DOCTYPE html>
<?php
//ini_set('display_errors', 'On');?>
<head>
<title>Log In</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="flows.css">
</head>
<body>
<div id="content" style="width:90%">
	<div id="container" class="container" style="width:100%">
		<h1>Welcome!</h1>
		<form action="listFlows.php" method="post">
		Username:<br>
		<input type="text" name="username">
		<br>
		Password:<br>
		<input type="password" name="password">
		<br>
		Server:<br>
		<input type="text" name="server"><br>
		<br>
		<input type="submit" value="Submit">
		</form>
	</div>
</div>
</body>
</html>


