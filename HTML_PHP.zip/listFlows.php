<!DOCTYPE html>
<html>
<head>
<title>Flows</title>
<link rel="stylesheet" type="text/css" href="flows.css">
</head>
<body>
<div id="content">
<?php
//ini_set('display_errors', 'On');
/*******************************************************************************************************/
/* For more information on logging into the Salesforce servers:                                        */
/* https://developer.salesforce.com/docs/atlas.en-us.api_rest.meta/api_rest/intro_what_is_rest_api.htm */
/*******************************************************************************************************/
$curl = curl_init();
$url = 'http://' . $_POST['server'] . '/services/oauth2/token';

curl_setopt_array($curl, array(
	CURLOPT_HEADER => false,
	CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $url,
	CURLOPT_POST => 1,
	CURLOPT_POSTFIELDS => array(
		'grant_type' => 'password',
		'client_id' => '3MVG9AOp4kbriZOJumg9bADs9LnN67Y.SWLCAU6HXi7ifVNuo0u.xhjWZqCJEcPIuRs2_Sfs68mJUDFbfIG.u',
		'client_secret' => '5666694277694991632',
		'username' => $_POST['username'],
		'password' => $_POST['password']
	)
));

$resp = curl_exec($curl);
curl_close($curl);

$json = json_decode($resp);
$access = $json->{'access_token'};

$curl = curl_init();
$url = 'http://' . $_POST['server'] . '/services/data/v36.0/process/flows';

$header = 'Authorization: Bearer ' . $access;
curl_setopt_array($curl, array(
	CURLOPT_RETURNTRANSFER => 1,
	CURLOPT_URL => $url,
	CURLOPT_HTTPHEADER => array($header)
));

$resp = curl_exec($curl);
// echo var_dump(json_decode($resp, true));
$json = json_decode($resp);
curl_close($curl);

?>
<div>Choose a flow to run: </div>
<form action="flow.php" method="post">
<input type="hidden" name="access" value="<?php echo $access ?>">
<input type="hidden" name="method" value="POST">
<input type="hidden" name="server" value="<?php echo $_POST['server']?>">
<select name="flowName"><?php
foreach ($json->{'flows'} as $flow) {?>
	<option value="<?php echo $flow->{'name'} ?>"><?php echo $flow->{'label'} ?></option>
<?php
}
?>
</select>
<input type='submit'>
</form>
</div>
</body>
</html>
