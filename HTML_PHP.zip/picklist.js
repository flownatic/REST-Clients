var handleMSP = function(S1, S2) {
	for(var i = 0; i < S1.options.length; i++) {
		if(S1.options[i].selected == true) {
			var newRow = new Option(S1.options[i].text, S1.options[i].value);
			S2.options[S2.length] = newRow;
			newRow.setAttribute('id', S1.options[i].id);
			S1.options[i] = null;
			i--;
		}
	}
}